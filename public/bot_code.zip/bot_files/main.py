# =========================================================
# YasNum & VaultX - Main Bot Entry Point
# =========================================================

import os
import sys
import time
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

# ضمان إضافة مسار المجلد الحالي للمسارات
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

try:
    import telebot
    from telebot import types
except ImportError:
    class _DummyTypes:
        class InlineKeyboardMarkup:
            def __init__(self, *args, **kwargs): self.keyboard = []
            def add(self, *args): return self
            def row(self, *args): return self
        class InlineKeyboardButton:
            def __init__(self, text, callback_data=None, url=None):
                self.text = text; self.callback_data = callback_data; self.url = url
        class ReplyKeyboardMarkup:
            def __init__(self, *args, **kwargs): self.keyboard = []
            def add(self, *args): return self
            def row(self, *args): return self
        class KeyboardButton:
            def __init__(self, text): self.text = text
        class BotCommand:
            def __init__(self, command, description): pass
    types = _DummyTypes()
    class _DummyTeleBot:
        def __init__(self, *args, **kwargs): pass
        def message_handler(self, *args, **kwargs): return lambda f: f
        def callback_query_handler(self, *args, **kwargs): return lambda f: f
        def send_message(self, *args, **kwargs): pass
        def edit_message_text(self, *args, **kwargs): pass
        def answer_callback_query(self, *args, **kwargs): pass
        def get_me(self): return type("obj", (), {"username": "YasNumVaultXBot"})()
        def set_my_commands(self, *args, **kwargs): pass
        def delete_webhook(self, *args, **kwargs): pass
        def infinity_polling(self, *args, **kwargs): pass
    telebot = type("obj", (), {"TeleBot": _DummyTeleBot, "types": types})()
import config
import database as db

# استيراد معالجات الأحداث والأقسام المنسقة
from handlers.user_handler import register_user_handlers
from handlers.smm_handler import register_smm_handlers
from handlers.sms_handler import register_sms_handlers
from handlers.games_handler import register_games_handlers
from handlers.admin_handler import register_admin_handlers
from keyboards.main_kb import build_main_keyboard
from keyboards.smm_kb import build_smm_categories_keyboard

# =========================================================
# إعداد خادم الفحص الصحي (Health Check Server) لـ Render
# =========================================================
class HealthCheckHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain; charset=utf-8')
        self.end_headers()
        self.wfile.write(b"OK - YasNum & VaultX Bot is running 24/7")

    def log_message(self, format, *args):
        pass

def run_health_server():
    port = int(os.getenv("PORT", "10000"))
    server = HTTPServer(('0.0.0.0', port), HealthCheckHandler)
    print(f"✅ Health Check & Uptime Web Server running on port {port}")
    server.serve_forever()

# تشغيل خادم Uptime في خلفية النظام
threading.Thread(target=run_health_server, daemon=True).start()

# =========================================================
# تهيئة البوت وقواعد البيانات
# =========================================================
bot_token = config.BOT_TOKEN
bot = telebot.TeleBot(bot_token, parse_mode=None)

# تسجيل معالجات الأحداث لكل قسم
register_user_handlers(bot)
register_smm_handlers(bot)
register_sms_handlers(bot)
register_games_handlers(bot)
register_admin_handlers(bot)

# =========================================================
# المعالجات العامة والرجوع
# =========================================================
@bot.callback_query_handler(func=lambda call: call.data in ["back_to_main", "sms_main_apps", "btn_services_games"])
def handle_global_navigation(call):
    user_id = call.from_user.id
    is_admin = (user_id == config.ADMIN_ID)
    
    if call.data == "back_to_main":
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(
            call.message.chat.id,
            "🏠 **تمت العودة للقائمة الرئيسية:**",
            parse_mode="Markdown",
            reply_markup=build_main_keyboard(is_admin)
        )
    elif call.data == "btn_services_games":
        bot.edit_message_text(
            "👑 **قسم خدمات الرشق وزيادة المتابعين:**",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=build_smm_categories_keyboard()
        )
    bot.answer_callback_query(call.id)

# =========================================================
# تشغيل حلقة الاستماع (Polling Loop)
# =========================================================
def start_bot():
    print("🚀 YasNum & VaultX Combined Bot Engine Started Successfully...")
    try:
        bot.delete_webhook(drop_pending_updates=True)
    except Exception:
        pass

    try:
        commands = [
            types.BotCommand("start", "🏠 القائمة الرئيسية"),
            types.BotCommand("admin", "⚙️ لوحة الإدارة والتحكم")
        ]
        bot.set_my_commands(commands)
    except Exception:
        pass

    while True:
        try:
            bot.infinity_polling(timeout=20, long_polling_timeout=15, skip_pending=True)
        except Exception as e:
            print(f"Polling loop auto-recovery: {e}")
            time.sleep(3)

if __name__ == "__main__":
    start_bot()
